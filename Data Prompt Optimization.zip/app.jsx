/* global React, ReactDOM, I, ScreenRuns, ScreenRunDetail, ScreenNewRun, ScreenDatasets, ScreenProviders, ScreenMetrics, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakSelect, TweakSlider, TweakToggle */

const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "amber",
  "providerPreset": "mixed",
  "numSteps": 10,
  "animSpeed": 1.6,
  "autoplay": true,
  "density": "default"
}/*EDITMODE-END*/;

function Sidebar({ route, setRoute, runningRun, density }) {
  const items = [
    { id: "runs",      label: "Runs",       icon: <I.list /> },
    { id: "datasets",  label: "Datasets",   icon: <I.data /> },
    { id: "providers", label: "Providers",  icon: <I.prov /> },
    { id: "metrics",   label: "Metrics",    icon: <I.metric /> },
  ];
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">f</div>
        <div className="brand-name">promptforge</div>
        <div className="brand-ws">acme</div>
      </div>

      <button className="jump">
        <I.search style={{ width: 13, height: 13 }} />
        <span>Jump to…</span>
        <kbd>⌘K</kbd>
      </button>

      <div className="nav-section">
        <div className="nav-label">Platform</div>
        {items.map((it) => (
          <div key={it.id}
               className={`nav-item ${route.kind === it.id ? "active" : ""}`}
               onClick={() => setRoute({ kind: it.id })}>
            <span className="ico" style={{ display: "inline-flex" }}>{it.icon}</span>
            <span>{it.label}</span>
            {it.id === "runs" && <span className="count">{window.RUNS.length}</span>}
          </div>
        ))}
        <div className={`nav-item ${route.kind === "new" ? "active" : ""}`} onClick={() => setRoute({ kind: "new" })}>
          <span className="ico" style={{ display: "inline-flex" }}><I.plus /></span>
          <span>New run</span>
        </div>
      </div>

      <div className="nav-section">
        <div className="nav-label">Running</div>
        {runningRun && (
          <div className="run-pill" onClick={() => setRoute({ kind: "run", id: runningRun.id })}>
            <span className="dot" />
            <span className="name tnum">{runningRun.id}</span>
            <span className="pct tnum">{Math.round((runningRun.step / runningRun.totalSteps) * 100)}%</span>
          </div>
        )}
        <div className="run-pill" style={{ opacity: 0.6 }}>
          <span className="dot gray" />
          <span className="name muted">queued · 2</span>
        </div>
      </div>

      <div className="nav-section">
        <div className="nav-label">Recent</div>
        {window.RUNS.filter((r) => r.status === "completed").slice(0, 3).map((r) => (
          <div key={r.id} className="nav-item" style={{ paddingLeft: 12, fontSize: 11.5 }}
               onClick={() => setRoute({ kind: "run", id: r.id })}>
            <span className="dot green" style={{ width: 5, height: 5 }} />
            <span className="muted tnum">{r.id}</span>
          </div>
        ))}
      </div>

      <div className="user-card">
        <div className="user-avatar">EH</div>
        <div className="user-meta">
          <span className="n">Elena Hara</span>
          <span className="r">prompt eng · acme</span>
        </div>
        <I.cog className="gear" />
      </div>
    </aside>
  );
}

function App() {
  const [route, setRoute] = useState({ kind: "runs" });
  const [showTweaks, setShowTweaks] = useState(false);

  // wire tweaks protocol
  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === "__activate_edit_mode")   setShowTweaks(true);
      if (e.data?.type === "__deactivate_edit_mode") setShowTweaks(false);
    };
    window.addEventListener("message", handler);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", handler);
  }, []);

  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // apply theme + accent
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", t.theme);
    document.documentElement.setAttribute("data-accent", t.accent);
  }, [t.theme, t.accent]);

  const runningRun = window.RUNS.find((r) => r.status === "running");

  return (
    <div className={`shell ${t.density === "compact" ? "compact" : ""}`}>
      <Sidebar route={route} setRoute={setRoute} runningRun={runningRun} density={t.density} />
      <main className="main">
        <div className="main-inner">
          {route.kind === "runs" && (
            <ScreenRuns
              goRun={(id) => setRoute({ kind: "run", id })}
              goNew={() => setRoute({ kind: "new" })}
            />
          )}
          {route.kind === "run" && (
            <ScreenRunDetail
              key={route.id}
              runId={route.id}
              goRuns={() => setRoute({ kind: "runs" })}
              animSpeed={t.animSpeed}
              autoplayEnabled={t.autoplay}
              totalStepsTweak={t.numSteps}
            />
          )}
          {route.kind === "new" && (
            <ScreenNewRun
              goRuns={() => setRoute({ kind: "runs" })}
              providerPreset={t.providerPreset}
            />
          )}
          {route.kind === "datasets"  && <ScreenDatasets />}
          {route.kind === "providers" && <ScreenProviders />}
          {route.kind === "metrics"   && <ScreenMetrics />}
        </div>
      </main>

      {showTweaks && (
        <TweaksPanel onClose={() => {
          setShowTweaks(false);
          window.parent.postMessage({ type: "__edit_mode_dismissed" }, "*");
        }}>
          <TweakSection label="Theme" />
          <TweakRadio
            label="mode"
            value={t.theme}
            onChange={(v) => setTweak("theme", v)}
            options={["light", "dark"]}
          />
          <TweakSelect
            label="accent"
            value={t.accent}
            onChange={(v) => setTweak("accent", v)}
            options={["amber", "cyan", "violet", "green", "pink"]}
          />
          <TweakRadio
            label="density"
            value={t.density}
            onChange={(v) => setTweak("density", v)}
            options={["default", "compact"]}
          />

          <TweakSection label="Providers" />
          <TweakSelect
            label="preset"
            value={t.providerPreset}
            onChange={(v) => setTweak("providerPreset", v)}
            options={["mixed", "vllm-only", "anthropic-only", "ollama-only"]}
          />

          <TweakSection label="Live run" />
          <TweakSlider
            label="num_steps"
            min={4} max={20} step={1}
            value={t.numSteps}
            onChange={(v) => setTweak("numSteps", v)}
          />
          <TweakSlider
            label="anim speed"
            min={0.5} max={4} step={0.1}
            value={t.animSpeed}
            onChange={(v) => setTweak("animSpeed", v)}
          />
          <TweakToggle
            label="autoplay"
            value={t.autoplay}
            onChange={(v) => setTweak("autoplay", v)}
          />
        </TweaksPanel>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
