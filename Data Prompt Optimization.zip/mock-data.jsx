/* ─────────────────────────── mock data ─────────────────────────── */

const PROVIDERS = [
  { id: "vllm-h100",   kind: "openai_compatible", label: "vLLM (gpu-box-01)",       host: "http://gpu-box-01:8000/v1",   models: ["Qwen2.5-Coder-32B", "Qwen2.5-72B-Instruct"], status: "online", qps: 18.4 },
  { id: "vllm-a100",   kind: "openai_compatible", label: "vLLM (gpu-box-02)",       host: "http://gpu-box-02:8000/v1",   models: ["Qwen2.5-7B", "Mistral-7B-Instruct-v0.3"], status: "online", qps: 24.1 },
  { id: "anthropic",   kind: "anthropic",         label: "Anthropic API",            host: "https://api.anthropic.com",   models: ["claude-sonnet-4-20250514", "claude-opus-4-20250514", "claude-haiku-4-5"], status: "online", qps: 8.0 },
  { id: "openai",      kind: "openai_compatible", label: "OpenAI API",               host: "https://api.openai.com/v1",   models: ["gpt-4o", "gpt-4o-mini"], status: "online", qps: 10.0 },
  { id: "ollama-mac",  kind: "ollama",            label: "Ollama (laptop)",          host: "http://localhost:11434",      models: ["llama3.1:8b", "qwen2.5:7b"], status: "idle",   qps: 4.0 },
  { id: "sglang-prod", kind: "openai_compatible", label: "SGLang (prod-cluster)",    host: "http://sglang.prod:8000/v1",  models: ["DeepSeek-V3-0324"],         status: "online", qps: 32.0 },
  { id: "hf-local",    kind: "huggingface",       label: "HuggingFace pipeline",     host: "in-process",                  models: ["microsoft/phi-3-mini"], status: "offline", qps: 1.2 },
];

const DATASETS = [
  { id: "test-script-gen-v3",   rows: 142, cols: ["api_context", "requirement", "expected_output"], format: "jsonl", size: "412 KB", task: "code generation",   updated: "2h ago" },
  { id: "ticket-triage-v2",     rows:  84, cols: ["ticket_text", "category", "priority"],            format: "jsonl", size: "218 KB", task: "classification",     updated: "1d ago" },
  { id: "release-notes-eval",   rows:  60, cols: ["pr_diff", "release_note"],                        format: "jsonl", size: "604 KB", task: "summarization",      updated: "3d ago" },
  { id: "rag-fin-qa",           rows: 220, cols: ["context", "question", "answer"],                  format: "csv",   size: "1.2 MB", task: "rag-qa",              updated: "6h ago" },
  { id: "fn-call-tool-router",  rows:  48, cols: ["user_msg", "tool_name", "args_json"],             format: "jsonl", size: "96 KB",  task: "tool-routing",        updated: "12d ago" },
  { id: "support-tone-rewrite", rows: 110, cols: ["draft", "polished"],                              format: "jsonl", size: "188 KB", task: "rewriting",           updated: "5h ago" },
];

const METRICS = [
  { id: "rouge_l",            kind: "compute", desc: "Longest common subsequence overlap" },
  { id: "rouge_1",            kind: "compute", desc: "Unigram overlap" },
  { id: "rouge_2",            kind: "compute", desc: "Bigram overlap" },
  { id: "bleu",               kind: "compute", desc: "Token n-gram precision (sacrebleu)" },
  { id: "exact_match",        kind: "compute", desc: "Strip + equality" },
  { id: "json_valid",         kind: "compute", desc: "json.loads(prediction) succeeds" },
  { id: "regex_match",        kind: "compute", desc: "User-supplied regex" },
  { id: "judge:coherence",    kind: "judge",   desc: "Logical flow & readability (1–5)" },
  { id: "judge:groundedness", kind: "judge",   desc: "Stays inside provided context (1–5)" },
  { id: "judge:relevance",    kind: "judge",   desc: "Addresses the user's question (1–5)" },
  { id: "judge:fluency",      kind: "judge",   desc: "Grammar & naturalness (1–5)" },
  { id: "judge:safety",       kind: "judge",   desc: "No harmful content (1–5)" },
  { id: "judge:instruction_following", kind: "judge", desc: "Adheres to system constraints (1–5)" },
  { id: "judge:completeness", kind: "judge",   desc: "Covers all aspects (1–5)" },
  { id: "custom:py_lint",     kind: "custom",  desc: "ruff + black pass rate (custom)" },
];

/* runs */
const RUNS = [
  {
    id: "run_481", name: "test-script-gen v3", status: "running",
    mode: "instruction", metric: "rouge_l",
    target: "Qwen2.5-Coder-32B (vllm)", rewriter: "claude-sonnet-4 (anthropic)", judge: "—",
    dataset: "test-script-gen-v3", samples: 50,
    baseline: 0.72, current: 0.81, best: 0.81,
    step: 6, totalSteps: 10,
    started: "12m ago",
    trend: [0.72, 0.74, 0.74, 0.78, 0.78, 0.78, 0.81],
  },
  {
    id: "run_478", name: "ticket-triage tone", status: "completed",
    mode: "instruction_and_demo", metric: "weighted (judge×0.6 + match×0.4)",
    target: "claude-haiku-4-5", rewriter: "claude-sonnet-4", judge: "claude-sonnet-4",
    dataset: "ticket-triage-v2", samples: 60,
    baseline: 0.61, current: 0.84, best: 0.84,
    step: 12, totalSteps: 12,
    started: "1h ago",
    trend: [0.61, 0.66, 0.71, 0.69, 0.74, 0.78, 0.79, 0.81, 0.81, 0.83, 0.84, 0.84],
  },
  {
    id: "run_477", name: "release-notes summarizer", status: "completed",
    mode: "demonstration", metric: "rouge_l + judge:coherence",
    target: "gpt-4o-mini", rewriter: "—", judge: "gpt-4o",
    dataset: "release-notes-eval", samples: 40,
    baseline: 0.58, current: 0.73, best: 0.73,
    step: 15, totalSteps: 15,
    started: "4h ago",
    trend: [0.58, 0.59, 0.62, 0.62, 0.65, 0.66, 0.66, 0.69, 0.69, 0.70, 0.71, 0.71, 0.72, 0.73, 0.73],
  },
  {
    id: "run_476", name: "rag-fin-qa groundedness", status: "completed",
    mode: "instruction", metric: "judge:groundedness",
    target: "Qwen2.5-72B (vllm)", rewriter: "Qwen2.5-72B (vllm)", judge: "claude-sonnet-4",
    dataset: "rag-fin-qa", samples: 80,
    baseline: 0.79, current: 0.91, best: 0.91,
    step: 10, totalSteps: 10,
    started: "1d ago",
    trend: [0.79, 0.81, 0.83, 0.83, 0.86, 0.86, 0.88, 0.89, 0.91, 0.91],
  },
  {
    id: "run_472", name: "fn-call tool router", status: "failed",
    mode: "instruction", metric: "exact_match",
    target: "llama3.1:8b (ollama)", rewriter: "claude-sonnet-4", judge: "—",
    dataset: "fn-call-tool-router", samples: 48,
    baseline: 0.42, current: 0.42, best: 0.46,
    step: 4, totalSteps: 12,
    started: "2d ago",
    trend: [0.42, 0.44, 0.46, 0.43, 0.42],
    error: "judge_model.healthcheck() failed after 3 retries",
  },
  {
    id: "run_469", name: "support-tone polish (A/B)", status: "completed",
    mode: "instruction", metric: "judge:fluency",
    target: "claude-sonnet-4", rewriter: "claude-sonnet-4", judge: "claude-haiku-4-5",
    dataset: "support-tone-rewrite", samples: 70,
    baseline: 0.74, current: 0.86, best: 0.86,
    step: 8, totalSteps: 8,
    started: "3d ago",
    trend: [0.74, 0.74, 0.77, 0.79, 0.81, 0.83, 0.85, 0.86],
  },
  {
    id: "run_465", name: "code-review chain (multi-step)", status: "draft",
    mode: "instruction_and_demo", metric: "weighted",
    target: "Qwen2.5-Coder-32B (vllm)", rewriter: "claude-opus-4", judge: "claude-sonnet-4",
    dataset: "test-script-gen-v3", samples: 30,
    baseline: null, current: null, best: null,
    step: 0, totalSteps: 20,
    started: "6d ago",
    trend: [],
  },
];

/* trajectory data for the live run (run_481) — extends as it runs */
const FULL_TRAJECTORY = [
  { step: 0, score: 0.724, delta: 0.000, kept: true,  preview: "You are a test-automation engineer. Write pytest functions…" },
  { step: 1, score: 0.741, delta: 0.017, kept: true,  preview: "You are an expert in pytest. For each requirement produce…" },
  { step: 2, score: 0.738, delta: -0.003, kept: false, preview: "You write Python test scripts. Cover edge cases…" },
  { step: 3, score: 0.776, delta: 0.035, kept: true,  preview: "You are a senior test-automation engineer. Output a single…" },
  { step: 4, score: 0.781, delta: 0.005, kept: true,  preview: "You are a senior test-automation engineer producing pytest…" },
  { step: 5, score: 0.769, delta: -0.012, kept: false, preview: "Generate a complete test module. Include fixtures…" },
  { step: 6, score: 0.812, delta: 0.031, kept: true,  preview: "You are a senior test-automation engineer. Given the API…" },
  { step: 7, score: 0.805, delta: -0.007, kept: false, preview: "You are a senior test-automation engineer. Use parametrize…" },
  { step: 8, score: 0.831, delta: 0.019, kept: true,  preview: "Produce a single self-contained pytest module. The first…" },
  { step: 9, score: 0.847, delta: 0.016, kept: true,  preview: "Produce one pytest module per requirement. Always import…" },
];

const BASELINE_INSTRUCTION = `You are an expert test automation engineer.
Given an API context and a requirement, write a Python test script
that exercises the requirement using pytest.`;

const BEST_INSTRUCTION = `You are a senior test-automation engineer producing pytest modules
for a Camera Hardware Abstraction Layer.

Hard requirements (apply EVERY time):
1. Output a single, self-contained \`.py\` module — no prose, no fences.
2. The first non-import line MUST be a module-level docstring summarising
   the requirement under test in one sentence.
3. Use \`pytest.mark.parametrize\` whenever the requirement implies a
   range of inputs (brightness 0–100, exposure stops, focus distances).
4. For hardware mocks, derive a fixture from \`conftest.MockCamera\`
   rather than instantiating real classes.
5. Each test function name must follow \`test_<feature>_<condition>_<expectation>\`.
6. End every file with a single \`if __name__ == "__main__": pytest.main(...)\`.

If the requirement is ambiguous, prefer the more conservative test
(narrower input range, stricter assertions). Never invent API surface
that is not visible in the provided context.`;

const SAMPLE_FAILURES = [
  {
    id: 14, score: 0.42,
    input: "Test brightness range 0-100",
    expected: "def test_brightness_range():\n    cam = MockCamera()\n    for v in range(0, 101, 10):\n        cam.set_brightness(v)\n        assert cam.get_brightness() == v",
    got: "def test_brightness():\n    cam = Camera()\n    cam.set_brightness(50)\n    assert True",
    judge: "Missed parametrization; did not iterate range; uses real Camera class",
  },
  {
    id: 23, score: 0.51,
    input: "Auto-focus in low light",
    expected: "@pytest.mark.parametrize('lux', [0.5, 1, 5])\ndef test_autofocus_low_light(lux):\n    ...",
    got: "def test_autofocus():\n    pass",
    judge: "Empty body, no parametrization, no fixture",
  },
  {
    id: 31, score: 0.55,
    input: "Capture rejects when battery < 5%",
    expected: "def test_capture_low_battery_raises():\n    cam = MockCamera(battery=4)\n    with pytest.raises(LowBatteryError):\n        cam.capture()",
    got: "def test_battery():\n    assert MockCamera().battery > 0",
    judge: "Doesn't exercise the rejection path; wrong assertion",
  },
];

const PER_SAMPLE = Array.from({ length: 18 }, (_, i) => {
  const base = 0.45 + Math.random() * 0.4;
  const after = Math.min(0.99, base + 0.1 + Math.random() * 0.25);
  const reqs = [
    "Test brightness range 0-100", "Auto-focus in low light", "Capture rejects when battery < 5%",
    "Set ISO to 100/200/400/800", "Burst mode of 5 frames", "White balance preset", "HDR off when battery saver on",
    "Self-timer 2/5/10s", "RAW capture path", "Reject capture when SD card full", "Recover after USB resume",
    "Frame rate 24/30/60", "Lens stability flag", "Thermal throttle warning", "Geo-tag toggle",
    "Save format jpg/png/raw", "Preview pause on call", "Capture interrupt safety",
  ];
  return {
    id: i + 1,
    requirement: reqs[i] || `Sample ${i + 1}`,
    before: +base.toFixed(2),
    after: +after.toFixed(2),
    delta: +(after - base).toFixed(2),
  };
});

const LIVE_LOG = [
  { ts: "12:04:01", lv: "info", msg: "Loading config from ./configs/test_script_gen.yaml" },
  { ts: "12:04:01", lv: "ok",   msg: "✓ Config validated (Pydantic)" },
  { ts: "12:04:02", lv: "info", msg: "Resolving providers…" },
  { ts: "12:04:02", lv: "ok",   msg: "✓ target_model: vLLM @ http://gpu-box-01:8000/v1 — Qwen2.5-Coder-32B" },
  { ts: "12:04:02", lv: "ok",   msg: "✓ rewriter_model: anthropic — claude-sonnet-4-20250514" },
  { ts: "12:04:02", lv: "meta", msg: "  judge_model: not set (compute-only metrics)" },
  { ts: "12:04:03", lv: "info", msg: "Loading dataset: test-script-gen-v3 (142 rows → 50 sampled)" },
  { ts: "12:04:04", lv: "ok",   msg: "✓ Health checks passed (target=18.4 qps, rewriter=8.0 qps)" },
  { ts: "12:04:05", lv: "info", msg: "[Step 0/10] Evaluating baseline instruction…" },
  { ts: "12:04:34", lv: "ok",   msg: "[Step 0/10] baseline rouge_l=0.724 (50 samples in 28.3s)" },
  { ts: "12:04:35", lv: "info", msg: "[Step 1/10] Asking rewriter for candidate (showing 5 worst examples)…" },
  { ts: "12:04:41", lv: "ok",   msg: "[Step 1/10] candidate rouge_l=0.741 (+2.3%) ✓ new best" },
  { ts: "12:05:12", lv: "info", msg: "[Step 2/10] Asking rewriter…" },
  { ts: "12:05:48", lv: "warn", msg: "[Step 2/10] candidate rouge_l=0.738 (-0.4%) ✗ keeping previous" },
  { ts: "12:06:22", lv: "info", msg: "[Step 3/10] Asking rewriter…" },
  { ts: "12:06:54", lv: "ok",   msg: "[Step 3/10] candidate rouge_l=0.776 (+4.7%) ✓ new best" },
  { ts: "12:07:30", lv: "info", msg: "[Step 4/10] Asking rewriter…" },
  { ts: "12:08:02", lv: "ok",   msg: "[Step 4/10] candidate rouge_l=0.781 (+0.6%) ✓ new best" },
  { ts: "12:08:38", lv: "info", msg: "[Step 5/10] Asking rewriter…" },
  { ts: "12:09:11", lv: "warn", msg: "[Step 5/10] candidate rouge_l=0.769 (-1.5%) ✗ keeping previous" },
  { ts: "12:09:48", lv: "info", msg: "[Step 6/10] Asking rewriter…" },
  { ts: "12:10:21", lv: "ok",   msg: "[Step 6/10] candidate rouge_l=0.812 (+4.0%) ✓ new best" },
  { ts: "12:10:55", lv: "info", msg: "[Step 7/10] Asking rewriter…" },
];

const DATASET_PREVIEW = [
  { api_context: "class Camera:\n  def capture(): ...\n  def set_brightness(v): ...", requirement: "Test auto-focus in low light",         expected_output: "@pytest.mark.parametrize('lux', [0.5, 1, 5])\ndef test_autofocus_low_light(lux): ..." },
  { api_context: "class Display:\n  def set_brightness(v): ...",                       requirement: "Test brightness range 0-100",            expected_output: "def test_brightness_range():\n  cam = MockCamera()\n  ..." },
  { api_context: "class Battery:\n  def level() -> int: ...",                          requirement: "Capture rejects when battery < 5%",      expected_output: "def test_capture_low_battery_raises(): ..." },
  { api_context: "class ISO:\n  def set(v: int): ...",                                  requirement: "Set ISO to 100/200/400/800",             expected_output: "@pytest.mark.parametrize('iso', [100,200,400,800])\n..." },
  { api_context: "class BurstMode:\n  def shoot(n: int): ...",                          requirement: "Burst mode of 5 frames",                  expected_output: "def test_burst_mode_five_frames(): ..." },
  { api_context: "class WhiteBalance:\n  def preset(name: str): ...",                   requirement: "White balance preset",                     expected_output: "def test_white_balance_preset_known_values(): ..." },
];

Object.assign(window, {
  PROVIDERS, DATASETS, METRICS, RUNS,
  FULL_TRAJECTORY, BASELINE_INSTRUCTION, BEST_INSTRUCTION,
  SAMPLE_FAILURES, PER_SAMPLE, LIVE_LOG, DATASET_PREVIEW,
});
