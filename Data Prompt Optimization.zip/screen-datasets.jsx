/* global React, I, Badge */
const { useState: useStateDS } = React;

function ScreenDatasets({ }) {
  const [open, setOpen] = useStateDS(null);
  const ds = open ? window.DATASETS.find((d) => d.id === open) : null;

  return (
    <div data-screen-label="Datasets">
      <div className="page-head">
        <div>
          <h1 className="page-title">Datasets</h1>
          <div className="page-meta">
            <span>{window.DATASETS.length} datasets</span>
            <span className="sep">·</span>
            <span>{window.DATASETS.reduce((a, b) => a + b.rows, 0).toLocaleString()} rows total</span>
          </div>
        </div>
        <div className="page-actions">
          <button className="btn"><I.download /> export</button>
          <button className="btn btn-primary"><I.plus /> upload</button>
        </div>
      </div>

      <table className="tbl">
        <thead>
          <tr>
            <th>Name</th>
            <th>Task</th>
            <th>Format</th>
            <th>Columns</th>
            <th className="num">Rows</th>
            <th className="num">Size</th>
            <th>Updated</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {window.DATASETS.map((d) => (
            <tr key={d.id} onClick={() => setOpen(d.id)}>
              <td className="name"><I.data style={{ width: 13, height: 13, marginRight: 8, color: "var(--ink-3)", verticalAlign: -2 }} />{d.id}</td>
              <td><Badge tone="teal">{d.task}</Badge></td>
              <td><span className="muted">{d.format}</span></td>
              <td>
                <div className="row" style={{ gap: 4, flexWrap: "wrap" }}>
                  {d.cols.map((c) => <span key={c} className="badge outline" style={{ fontSize: 10 }}>{c}</span>)}
                </div>
              </td>
              <td className="num tnum">{d.rows.toLocaleString()}</td>
              <td className="num"><span className="muted">{d.size}</span></td>
              <td><span className="muted">{d.updated}</span></td>
              <td><span className="arrow"><I.arrow /></span></td>
            </tr>
          ))}
        </tbody>
      </table>

      {ds && <DatasetDrawer ds={ds} onClose={() => setOpen(null)} />}
    </div>
  );
}

function DatasetDrawer({ ds, onClose }) {
  const [tab, setTab] = useStateDS("preview");
  return (
    <>
      <div className="drawer-bd" onClick={onClose} />
      <aside className="drawer">
        <div className="card-head" style={{ background: "var(--bg)" }}>
          <div className="t" style={{ fontSize: 14 }}><I.data style={{ width: 13, height: 13, verticalAlign: -2, marginRight: 6 }} />{ds.id}</div>
          <div className="m">{ds.rows} rows · {ds.size} · {ds.format}</div>
          <div className="actions">
            <button className="btn"><I.copy /> path</button>
            <button className="btn btn-icon" onClick={onClose}><I.close /></button>
          </div>
        </div>
        <div className="tabs" style={{ margin: "0 16px" }}>
          {["preview", "schema", "stats"].map((t) => (
            <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>{t}</button>
          ))}
        </div>
        <div style={{ padding: "0 16px 16px", overflowY: "auto" }}>
          {tab === "preview" && <DatasetPreview ds={ds} />}
          {tab === "schema" && <DatasetSchema ds={ds} />}
          {tab === "stats" && <DatasetStats ds={ds} />}
        </div>
      </aside>
    </>
  );
}

function DatasetPreview({ ds }) {
  return (
    <div className="card" style={{ marginTop: 12 }}>
      <div className="card-head">
        <div className="t">First 6 rows</div>
        <div className="m">jsonl · use ↑↓ to step</div>
      </div>
      <div style={{ overflow: "auto" }}>
        <table className="tbl compact-tbl" style={{ tableLayout: "fixed" }}>
          <thead>
            <tr>
              <th style={{ width: 40 }}>#</th>
              {ds.cols.map((c) => <th key={c}>{c}</th>)}
            </tr>
          </thead>
          <tbody>
            {window.DATASET_PREVIEW.slice(0, 6).map((r, i) => (
              <tr key={i}>
                <td className="muted tnum">{i + 1}</td>
                {ds.cols.map((c) => (
                  <td key={c} style={{ verticalAlign: "top", maxWidth: 280 }}>
                    <pre style={{ margin: 0, whiteSpace: "pre-wrap", fontSize: 11.5, lineHeight: 1.5, color: "var(--ink-2)" }}>
                      {(r[c] || "—").slice(0, 200)}
                    </pre>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DatasetSchema({ ds }) {
  return (
    <div className="card" style={{ marginTop: 12 }}>
      <div className="card-head"><div className="t">Schema</div></div>
      <div className="card-body">
        <table className="tbl compact-tbl">
          <thead><tr><th>column</th><th>inferred type</th><th>nullable</th><th>used in</th></tr></thead>
          <tbody>
            {ds.cols.map((c, i) => (
              <tr key={c}>
                <td className="name">{c}</td>
                <td><Badge tone="blue">{i === ds.cols.length - 1 ? "string · long" : "string"}</Badge></td>
                <td className="muted">no</td>
                <td className="muted">{i === ds.cols.length - 1 ? "reference_column" : "{template var}"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DatasetStats({ ds }) {
  return (
    <div className="grid-2" style={{ marginTop: 12, gap: 12 }}>
      {ds.cols.map((c, i) => (
        <div key={c} className="card" style={{ padding: 12 }}>
          <div className="faint" style={{ fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 6 }}>{c}</div>
          <div className="kv">
            <div className="k">avg chars</div><div className="v tnum">{[42, 86, 240, 60, 110, 180][i] || 80}</div>
            <div className="k">p50 chars</div><div className="v tnum">{[36, 78, 210, 52, 95, 165][i] || 75}</div>
            <div className="k">p99 chars</div><div className="v tnum">{[120, 240, 980, 180, 320, 540][i] || 210}</div>
            <div className="k">unique</div><div className="v tnum">{ds.rows}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

window.ScreenDatasets = ScreenDatasets;
