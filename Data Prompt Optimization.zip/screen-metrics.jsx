/* global React, I, Badge */
function ScreenMetrics() {
  return (
    <div data-screen-label="Metrics">
      <div className="page-head">
        <div>
          <h1 className="page-title">Metrics catalog</h1>
          <div className="page-meta">
            <span>{window.METRICS.length} metrics</span>
            <span className="sep">·</span>
            <span>{window.METRICS.filter((m) => m.kind === "compute").length} compute</span>
            <span className="sep">·</span>
            <span>{window.METRICS.filter((m) => m.kind === "judge").length} judge</span>
            <span className="sep">·</span>
            <span>{window.METRICS.filter((m) => m.kind === "custom").length} custom</span>
          </div>
        </div>
        <div className="page-actions">
          <button className="btn btn-primary"><I.plus /> register custom metric</button>
        </div>
      </div>

      <div className="grid-3">
        {window.METRICS.map((m) => (
          <div key={m.id} className="card" style={{ padding: 14 }}>
            <div className="row" style={{ marginBottom: 8 }}>
              <span className="tnum" style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{m.id}</span>
              <span className="spacer" />
              <Badge tone={m.kind === "compute" ? "blue" : m.kind === "judge" ? "amber" : "violet"}>{m.kind}</Badge>
            </div>
            <div className="muted" style={{ fontSize: 12, lineHeight: 1.5, marginBottom: 10 }}>{m.desc}</div>
            <div className="row" style={{ gap: 6, fontSize: 11 }}>
              <span className="faint">used in</span>
              <span className="tnum">{Math.floor(Math.random() * 24) + 1}</span>
              <span className="faint">runs</span>
              <span className="spacer" />
              <button className="btn btn-icon"><I.arrow /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

window.ScreenMetrics = ScreenMetrics;
