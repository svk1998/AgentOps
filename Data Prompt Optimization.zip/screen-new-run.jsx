/* global React, I, Badge, Code */
const { useState: useStateNR } = React;

function ScreenNewRun({ goRuns, providerPreset = "mixed" }) {
  const [step, setStep] = useStateNR(1);
  const [mode, setMode] = useStateNR("instruction");
  const [dataset, setDataset] = useStateNR("test-script-gen-v3");
  const [metrics, setMetrics] = useStateNR(["rouge_l"]);
  const [numSteps, setNumSteps] = useStateNR(10);
  const [name, setName] = useStateNR("test-script-gen v4");
  const [demoSize, setDemoSize] = useStateNR(3);
  const [dataLimit, setDataLimit] = useStateNR(50);

  const presets = {
    mixed:    { target: "vllm-h100",   rewriter: "anthropic",  judge: "anthropic" },
    "vllm-only": { target: "vllm-h100", rewriter: "vllm-h100", judge: "vllm-h100" },
    "anthropic-only": { target: "anthropic", rewriter: "anthropic", judge: "anthropic" },
    "ollama-only": { target: "ollama-mac", rewriter: "ollama-mac", judge: "ollama-mac" },
  };
  const preset = presets[providerPreset] || presets.mixed;

  const [target, setTarget] = useStateNR(preset.target);
  const [rewriter, setRewriter] = useStateNR(preset.rewriter);
  const [judge, setJudge] = useStateNR(preset.judge);

  React.useEffect(() => {
    setTarget(preset.target);
    setRewriter(preset.rewriter);
    setJudge(preset.judge);
  }, [providerPreset]);

  const ds = window.DATASETS.find((d) => d.id === dataset);
  const tProv = window.PROVIDERS.find((p) => p.id === target);
  const rProv = window.PROVIDERS.find((p) => p.id === rewriter);
  const jProv = window.PROVIDERS.find((p) => p.id === judge);

  const totalCalls = (numSteps + 1) * dataLimit;
  const estTime = Math.round(totalCalls / 5 + numSteps * 4);

  return (
    <div data-screen-label="New Run · Wizard">
      <div className="page-head">
        <button className="btn btn-ghost btn-icon" onClick={goRuns} style={{ marginTop: 4 }}><I.back /></button>
        <div>
          <h1 className="page-title">New optimization run</h1>
          <div className="page-meta">
            <span>configure → review → launch</span>
          </div>
        </div>
        <div className="page-actions">
          <div className="row" style={{ gap: 6 }}>
            {[1, 2, 3].map((n) => (
              <div key={n} className="row" style={{ gap: 6 }}>
                <span className="tnum" style={{
                  width: 20, height: 20, borderRadius: 10, display: "grid", placeItems: "center", fontSize: 11,
                  background: step >= n ? "var(--accent-bg)" : "var(--bg-3)",
                  color: step >= n ? "var(--accent-ink)" : "var(--ink-3)",
                  border: "1px solid " + (step >= n ? "var(--accent-bg-h)" : "var(--line)"),
                }}>{n}</span>
                <span style={{ fontSize: 12, color: step === n ? "var(--ink)" : "var(--ink-3)" }}>
                  {["", "Setup", "Review", "Launch"][n]}
                </span>
                {n < 3 && <span className="faint" style={{ marginLeft: 6, marginRight: 4 }}>—</span>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {step === 1 && (
        <div className="grid-2" style={{ gridTemplateColumns: "1fr 380px", alignItems: "start" }}>
          <div className="col" style={{ gap: 16 }}>

            {/* basics */}
            <div className="card">
              <div className="card-head">
                <div className="t">Basics</div>
                <div className="m">name and prompt template</div>
              </div>
              <div className="card-body col" style={{ gap: 14 }}>
                <label className="field">
                  <div className="lbl">project_name <span className="req">*</span></div>
                  <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
                </label>
                <label className="field">
                  <div className="lbl">system_instruction <span className="faint">— starting point, will be rewritten</span></div>
                  <textarea className="textarea" rows={4} defaultValue={window.BASELINE_INSTRUCTION} />
                </label>
                <label className="field">
                  <div className="lbl">prompt_template <span className="faint">— Jinja-style {"{vars}"} resolved per row</span></div>
                  <textarea className="textarea" rows={6} defaultValue={`API Context:\n{api_context}\n\nRequirement:\n{requirement}\n\nWrite the test script.`} />
                </label>
              </div>
            </div>

            {/* dataset */}
            <div className="card">
              <div className="card-head">
                <div className="t">Dataset</div>
                <div className="m">{ds?.rows.toLocaleString()} rows · {ds?.format} · {ds?.size}</div>
                <div className="actions">
                  <button className="btn"><I.plus /> upload</button>
                </div>
              </div>
              <div className="card-body col" style={{ gap: 12 }}>
                <div className="row" style={{ flexWrap: "wrap", gap: 6 }}>
                  {window.DATASETS.map((d) => (
                    <button key={d.id} className={`btn ${d.id === dataset ? "btn-primary" : ""}`} onClick={() => setDataset(d.id)}>
                      <I.data /> {d.id}
                      <span className="faint tnum" style={{ marginLeft: 6 }}>n={d.rows}</span>
                    </button>
                  ))}
                </div>
                <div className="row">
                  <div className="faint" style={{ fontSize: 11 }}>Columns:</div>
                  <div className="row" style={{ gap: 4 }}>
                    {ds?.cols.map((c) => <span key={c} className="badge outline">{c}</span>)}
                  </div>
                  <span className="spacer" />
                  <div className="faint" style={{ fontSize: 11 }}>reference column:</div>
                  <select className="select" style={{ width: 180 }} defaultValue={ds?.cols[ds.cols.length - 1]}>
                    {ds?.cols.map((c) => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div className="row">
                  <label className="field" style={{ flex: 1, marginBottom: 0 }}>
                    <div className="lbl">data_limit <span className="faint">— rows per eval pass</span></div>
                    <input className="input" type="number" value={dataLimit} onChange={(e) => setDataLimit(+e.target.value)} />
                  </label>
                  <label className="field" style={{ flex: 1, marginBottom: 0 }}>
                    <div className="lbl">eval split</div>
                    <select className="select"><option>random 80/20</option><option>fixed (last 20%)</option><option>provided splits</option></select>
                  </label>
                </div>
              </div>
            </div>

            {/* mode */}
            <div className="card">
              <div className="card-head">
                <div className="t">Optimization mode</div>
              </div>
              <div className="card-body">
                <div className="grid-3">
                  {[
                    { id: "instruction", label: "instruction", desc: "Rewrite the system instruction iteratively.", tone: "blue" },
                    { id: "demonstration", label: "demonstration", desc: "Search for the best k few-shot examples to prepend.", tone: "violet" },
                    { id: "instruction_and_demo", label: "instruction + demo", desc: "First instruction, then demos using the optimized instruction.", tone: "teal" },
                  ].map((m) => (
                    <div key={m.id} onClick={() => setMode(m.id)}
                         className="card"
                         style={{
                           padding: 14, cursor: "pointer",
                           borderColor: mode === m.id ? "var(--accent)" : "var(--line)",
                           background: mode === m.id ? "var(--accent-soft)" : "var(--panel)",
                         }}>
                      <div className="row" style={{ marginBottom: 6 }}>
                        <span className={`badge ${m.tone}`}>{m.label}</span>
                        {mode === m.id && <span className="spacer" />}
                        {mode === m.id && <I.check style={{ width: 14, height: 14, color: "var(--accent)" }} />}
                      </div>
                      <div className="muted" style={{ fontSize: 12, lineHeight: 1.45 }}>{m.desc}</div>
                    </div>
                  ))}
                </div>

                <div className="grid-3" style={{ marginTop: 14 }}>
                  <label className="field" style={{ marginBottom: 0 }}>
                    <div className="lbl">num_steps</div>
                    <input className="input" type="number" value={numSteps} onChange={(e) => setNumSteps(+e.target.value)} />
                  </label>
                  <label className="field" style={{ marginBottom: 0 }}>
                    <div className="lbl">demo_set_size</div>
                    <input className="input" type="number" value={demoSize} onChange={(e) => setDemoSize(+e.target.value)} disabled={mode === "instruction"} />
                  </label>
                  <label className="field" style={{ marginBottom: 0 }}>
                    <div className="lbl">target qps</div>
                    <input className="input" type="number" defaultValue={5} step="0.5" />
                  </label>
                </div>
              </div>
            </div>

            {/* providers */}
            <div className="card">
              <div className="card-head">
                <div className="t">Provider chain</div>
                <div className="m">target / rewriter / judge — independent</div>
                <div className="actions">
                  <span className="faint" style={{ fontSize: 11 }}>preset · {providerPreset}</span>
                </div>
              </div>
              <div className="card-body">
                <div className="grid-3" style={{ gap: 18 }}>
                  <ProviderSlot role="target"   value={target}   onChange={setTarget}   tProv={tProv} />
                  <ProviderSlot role="rewriter" value={rewriter} onChange={setRewriter} tProv={rProv} sameAs={rewriter === target ? "target" : null} />
                  <ProviderSlot role="judge"    value={judge}    onChange={setJudge}    tProv={jProv} sameAs={judge === target ? "target" : judge === rewriter ? "rewriter" : null} />
                </div>
              </div>
            </div>

            {/* metrics */}
            <div className="card">
              <div className="card-head">
                <div className="t">Evaluation metrics</div>
                <div className="m">{metrics.length} selected · weighted_average</div>
                <div className="actions">
                  <button className="btn"><I.plus /> custom metric</button>
                </div>
              </div>
              <div className="card-body col" style={{ gap: 0 }}>
                {window.METRICS.map((m) => {
                  const on = metrics.includes(m.id);
                  return (
                    <label key={m.id} className="row" style={{ padding: "7px 0", borderBottom: "1px solid var(--line)", cursor: "pointer", gap: 10 }}
                           onClick={() => setMetrics((arr) => arr.includes(m.id) ? arr.filter((x) => x !== m.id) : [...arr, m.id])}>
                      <span className="check" style={{ pointerEvents: "none" }}>
                        <input type="checkbox" checked={on} readOnly />
                        <span className="box" />
                      </span>
                      <span style={{ width: 200 }}>{m.id}</span>
                      <Badge tone={m.kind === "compute" ? "blue" : m.kind === "judge" ? "amber" : "violet"}>{m.kind}</Badge>
                      <span className="muted" style={{ fontSize: 12 }}>{m.desc}</span>
                      <span className="spacer" />
                      {on && (
                        <input className="input" type="number" defaultValue={(1 / metrics.length).toFixed(2)} step="0.1" style={{ width: 80 }} onClick={(e) => e.stopPropagation()} />
                      )}
                    </label>
                  );
                })}
              </div>
            </div>
          </div>

          {/* sticky summary */}
          <div className="col" style={{ gap: 16, position: "sticky", top: 24 }}>
            <div className="card">
              <div className="card-head">
                <div className="t">Summary</div>
              </div>
              <div className="card-body col" style={{ gap: 14 }}>
                <KV items={[
                  ["mode", <Badge tone={mode === "instruction" ? "blue" : mode === "demonstration" ? "violet" : "teal"}>{mode}</Badge>],
                  ["dataset", <span>{dataset} <span className="faint">· n={ds?.rows}</span></span>],
                  ["metrics", <span>{metrics.length} · weighted_average</span>],
                  ["num_steps", <span className="tnum">{numSteps}</span>],
                  ["data_limit", <span className="tnum">{dataLimit}</span>],
                ]} />
                <hr />
                <KV items={[
                  ["target", <span>{tProv?.label}<div className="faint" style={{ fontSize: 11 }}>{tProv?.models[0]}</div></span>],
                  ["rewriter", <span>{rProv?.label}<div className="faint" style={{ fontSize: 11 }}>{rProv?.models[0]}</div></span>],
                  ["judge", <span>{jProv?.label}<div className="faint" style={{ fontSize: 11 }}>{jProv?.models[0]}</div></span>],
                ]} />
                <hr />
                <div>
                  <div className="faint" style={{ fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 6 }}>Estimate</div>
                  <KV items={[
                    ["target calls", <span className="tnum">{totalCalls.toLocaleString()}</span>],
                    ["rewriter calls", <span className="tnum">{numSteps}</span>],
                    ["wall clock", <span className="tnum">~ {Math.floor(estTime / 60)}m {estTime % 60}s</span>],
                  ]} />
                </div>
              </div>
            </div>

            <button className="btn btn-primary" style={{ justifyContent: "center", padding: "10px 14px" }} onClick={() => setStep(2)}>
              Review config <I.arrow />
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="grid-2" style={{ gridTemplateColumns: "1fr 380px", alignItems: "start" }}>
          <div className="card">
            <div className="card-head">
              <div className="t">Generated config.yaml</div>
              <div className="m">edit inline before launching</div>
              <div className="actions">
                <button className="btn"><I.copy /> copy</button>
                <button className="btn"><I.download /></button>
              </div>
            </div>
            <div style={{ padding: 12 }}>
              <Code>{`project_name: "${name}"

system_instruction: |
  ${window.BASELINE_INSTRUCTION.split("\n").join("\n  ")}

prompt_template: |
  API Context:
  {api_context}

  Requirement:
  {requirement}

dataset_path: "./data/${dataset}.jsonl"
output_dir: "./results/${name.replace(/\s+/g, "_")}/"

target_model:
  provider: "${tProv?.kind}"
  base_url: "${tProv?.host}"
  model: "${tProv?.models[0]}"
  temperature: 0.3
  max_tokens: 2048

rewriter_model:
  provider: "${rProv?.kind}"
  ${rProv?.kind === "anthropic" ? `model: "${rProv?.models[0]}"\n  api_key: "$ANTHROPIC_API_KEY"` : `base_url: "${rProv?.host}"\n  model: "${rProv?.models[0]}"`}
  temperature: 0.7

${jProv ? `judge_model:
  provider: "${jProv?.kind}"
  ${jProv?.kind === "anthropic" ? `model: "${jProv?.models[0]}"\n  api_key: "$ANTHROPIC_API_KEY"` : `base_url: "${jProv?.host}"\n  model: "${jProv?.models[0]}"`}
  temperature: 0.0\n` : ""}
optimization_mode: "${mode}"

eval_metrics:
${metrics.map((m) => `  - type: ${m}\n    weight: ${(1 / metrics.length).toFixed(2)}`).join("\n")}
aggregation: weighted_average

num_steps: ${numSteps}
${mode !== "instruction" ? `num_demo_trials: 15\ndemo_set_size: ${demoSize}\n` : ""}target_model_qps: 5.0
eval_qps: 5.0

data_limit: ${dataLimit}
`}</Code>
            </div>
          </div>

          <div className="col" style={{ gap: 16 }}>
            <div className="card">
              <div className="card-head">
                <div className="t">Pre-flight checks</div>
              </div>
              <div className="card-body col" style={{ gap: 8 }}>
                {[
                  { ok: true, label: "config.yaml validates (Pydantic)" },
                  { ok: true, label: "target reachable · 18.4 qps headroom" },
                  { ok: true, label: "rewriter reachable · 8.0 qps headroom" },
                  { ok: true, label: `${dataset} present · ${ds?.rows} rows` },
                  { ok: true, label: "{api_context} and {requirement} bind to dataset" },
                  { ok: false, label: "no judge_model — model-based metrics will be skipped", warn: true },
                ].map((c, i) => (
                  <div key={i} className="row" style={{ gap: 8 }}>
                    {c.ok ? <I.check style={{ width: 14, height: 14, color: "var(--green)" }} />
                          : <I.warn style={{ width: 14, height: 14, color: "var(--accent)" }} />}
                    <span className={c.warn ? "" : ""} style={{ color: c.warn ? "var(--ink-2)" : "var(--ink)", fontSize: 12 }}>
                      {c.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="row" style={{ gap: 8 }}>
              <button className="btn" style={{ flex: 1, justifyContent: "center" }} onClick={() => setStep(1)}>← back</button>
              <button className="btn btn-primary" style={{ flex: 2, justifyContent: "center" }} onClick={() => setStep(3)}>
                <I.run /> launch run
              </button>
            </div>
          </div>
        </div>
      )}

      {step === 3 && (
        <div style={{ display: "grid", placeItems: "center", padding: "60px 0" }}>
          <div className="card" style={{ width: 480, padding: 28, textAlign: "center" }}>
            <div className="row" style={{ justifyContent: "center", marginBottom: 14 }}>
              <span className="dot amber pulse" style={{ width: 12, height: 12 }} />
            </div>
            <div className="page-title" style={{ fontSize: 16, marginBottom: 6 }}>Launching run_482…</div>
            <div className="muted" style={{ fontSize: 12, marginBottom: 18 }}>
              Resolving providers, hashing dataset, evaluating baseline.
            </div>
            <div className="bar-meter" style={{ marginBottom: 18 }}><div className="fill" style={{ width: "62%" }} /></div>
            <div className="row" style={{ justifyContent: "center", gap: 8 }}>
              <button className="btn" onClick={() => setStep(2)}>← back</button>
              <button className="btn btn-primary" onClick={goRuns}>open dashboard</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ProviderSlot({ role, value, onChange, tProv, sameAs }) {
  return (
    <div className="slot">
      <span className="role-tag">{role}</span>
      <div className="row">
        <span className="dot green" />
        <select className="select" value={value} onChange={(e) => onChange(e.target.value)} style={{ flex: 1 }}>
          {window.PROVIDERS.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
        </select>
      </div>
      <div className="faint" style={{ fontSize: 11 }}>
        <span style={{ display: "block" }}>{tProv?.host}</span>
      </div>
      <div>
        <div className="faint" style={{ fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 4 }}>model</div>
        <select className="select" defaultValue={tProv?.models[0]}>
          {tProv?.models.map((m) => <option key={m}>{m}</option>)}
        </select>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <label className="field" style={{ flex: 1, marginBottom: 0 }}>
          <div className="lbl">temp</div>
          <input className="input" type="number" defaultValue={role === "rewriter" ? 0.7 : role === "judge" ? 0.0 : 0.3} step="0.1" />
        </label>
        <label className="field" style={{ flex: 1, marginBottom: 0 }}>
          <div className="lbl">max_tokens</div>
          <input className="input" type="number" defaultValue={2048} />
        </label>
      </div>
      {sameAs && (
        <div className="row" style={{ gap: 6, marginTop: -4 }}>
          <I.link style={{ width: 11, height: 11, color: "var(--ink-3)" }} />
          <span className="faint" style={{ fontSize: 11 }}>linked to {sameAs}</span>
        </div>
      )}
    </div>
  );
}

function KV({ items }) {
  return (
    <div className="kv">
      {items.map(([k, v], i) => (
        <React.Fragment key={i}>
          <div className="k">{k}</div>
          <div className="v">{v}</div>
        </React.Fragment>
      ))}
    </div>
  );
}

window.ScreenNewRun = ScreenNewRun;
