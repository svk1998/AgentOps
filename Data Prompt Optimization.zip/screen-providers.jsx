/* global React, I, Badge */
const { useState: useStatePR } = React;

function ScreenProviders() {
  return (
    <div data-screen-label="Providers">
      <div className="page-head">
        <div>
          <h1 className="page-title">Providers</h1>
          <div className="page-meta">
            <span>{window.PROVIDERS.length} configured</span>
            <span className="sep">·</span>
            <span>{window.PROVIDERS.filter((p) => p.status === "online").length} online</span>
            <span className="sep">·</span>
            <span>1 offline</span>
          </div>
        </div>
        <div className="page-actions">
          <button className="btn btn-primary"><I.plus /> add provider</button>
        </div>
      </div>

      <div className="muted" style={{ fontSize: 12, marginBottom: 14 }}>
        Each role (target / rewriter / judge) can use a different provider. The optimizer is backend-agnostic — only this config block changes.
      </div>

      <div className="grid-2" style={{ gridTemplateColumns: "1.4fr 1fr", alignItems: "start" }}>
        <table className="tbl">
          <thead>
            <tr>
              <th>Provider</th>
              <th>Kind</th>
              <th>Models</th>
              <th>Endpoint</th>
              <th className="num">qps cap</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {window.PROVIDERS.map((p) => (
              <tr key={p.id}>
                <td className="name"><I.prov style={{ width: 13, height: 13, marginRight: 8, color: "var(--ink-3)", verticalAlign: -2 }} />{p.label}</td>
                <td><Badge tone={p.kind === "anthropic" ? "amber" : p.kind === "ollama" ? "violet" : p.kind === "huggingface" ? "teal" : "blue"}>{p.kind}</Badge></td>
                <td>
                  <div style={{ fontSize: 11 }}>
                    <div>{p.models[0]}</div>
                    {p.models.length > 1 && <div className="faint">+{p.models.length - 1} more</div>}
                  </div>
                </td>
                <td><span className="muted" style={{ fontSize: 11 }}>{p.host}</span></td>
                <td className="num tnum">{p.qps}</td>
                <td>
                  {p.status === "online" && <Badge tone="green" dot="green">online</Badge>}
                  {p.status === "idle" && <Badge tone="amber">idle</Badge>}
                  {p.status === "offline" && <Badge tone="red" dot="red">offline</Badge>}
                </td>
                <td><span className="arrow"><I.arrow /></span></td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="card">
          <div className="card-head">
            <div className="t">Mix-and-match recipes</div>
            <div className="m">click to apply across roles</div>
          </div>
          <div className="card-body col" style={{ gap: 10 }}>
            {[
              {
                name: "Air-gapped",
                desc: "Everything on a single self-hosted vLLM",
                t: "vllm-h100", r: "vllm-h100", j: "vllm-h100",
              },
              {
                name: "Smart rewriter",
                desc: "Local target, Claude as the meta-rewriter",
                t: "vllm-a100", r: "anthropic", j: "vllm-h100",
              },
              {
                name: "Laptop dev",
                desc: "All Ollama, all the time",
                t: "ollama-mac", r: "ollama-mac", j: "ollama-mac",
              },
              {
                name: "Cloud only",
                desc: "OpenAI target, Claude rewriter, gpt-4o-mini judge",
                t: "openai", r: "anthropic", j: "openai",
              },
            ].map((rec) => {
              const tt = window.PROVIDERS.find((p) => p.id === rec.t);
              const rr = window.PROVIDERS.find((p) => p.id === rec.r);
              const jj = window.PROVIDERS.find((p) => p.id === rec.j);
              return (
                <div key={rec.name} className="card" style={{ padding: 12 }}>
                  <div className="row" style={{ marginBottom: 6 }}>
                    <div style={{ fontSize: 13 }}>{rec.name}</div>
                    <span className="spacer" />
                    <button className="btn">apply</button>
                  </div>
                  <div className="muted" style={{ fontSize: 11, marginBottom: 8 }}>{rec.desc}</div>
                  <div className="row" style={{ flexWrap: "wrap", gap: 6, fontSize: 10 }}>
                    <span className="badge outline"><span className="faint">target</span> · {tt?.label}</span>
                    <span className="badge outline"><span className="faint">rewriter</span> · {rr?.label}</span>
                    <span className="badge outline"><span className="faint">judge</span> · {jj?.label}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div style={{ marginTop: 24 }}>
        <div className="muted" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 8 }}>
          Provider interface
        </div>
        <pre className="code">{`from abc import ABC, abstractmethod

class LLMProvider(ABC):
    """All LLM backends implement this single interface."""

    @abstractmethod
    async def generate(
        self,
        messages: list[Message],
        temperature: float = 0.3,
        max_tokens: int = 2048,
        response_format: str | None = None,
    ) -> GenerateResponse: ...

    @abstractmethod
    async def healthcheck(self) -> bool: ...`}</pre>
      </div>
    </div>
  );
}

window.ScreenProviders = ScreenProviders;
