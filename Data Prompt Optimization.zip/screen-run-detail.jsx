/* global React, I, Badge, Sparkline, ProgressRing, Code, KV, TrajectoryChart */
const { useState: useStateRD, useEffect: useEffectRD, useRef: useRefRD, useMemo: useMemoRD } = React;

function StatusPill({ s, step, total }) {
  if (s === "running") return (
    <span className="badge amber" style={{ padding: "2px 8px" }}>
      <span className="dot amber pulse" /> running · step {step}/{total}
    </span>
  );
  if (s === "completed") return <span className="badge green" style={{ padding: "2px 8px" }}>completed · {step} steps</span>;
  if (s === "failed") return <span className="badge red" style={{ padding: "2px 8px" }}>failed · step {step}/{total}</span>;
  return <span className="badge gray" style={{ padding: "2px 8px" }}>{s}</span>;
}

function ProviderChain({ target, rewriter, judge }) {
  return (
    <div className="row" style={{ gap: 8, alignItems: "center", flexWrap: "wrap" }}>
      <div className="card" style={{ padding: "6px 10px", display: "flex", alignItems: "center", gap: 6, fontSize: 11 }}>
        <span className="faint" style={{ fontSize: 10 }}>TARGET</span>
        <span>{target}</span>
      </div>
      <span className="faint">→</span>
      <div className="card" style={{ padding: "6px 10px", display: "flex", alignItems: "center", gap: 6, fontSize: 11 }}>
        <span className="faint" style={{ fontSize: 10 }}>REWRITER</span>
        <span>{rewriter}</span>
      </div>
      {judge && judge !== "—" && (
        <>
          <span className="faint">→</span>
          <div className="card" style={{ padding: "6px 10px", display: "flex", alignItems: "center", gap: 6, fontSize: 11 }}>
            <span className="faint" style={{ fontSize: 10 }}>JUDGE</span>
            <span>{judge}</span>
          </div>
        </>
      )}
    </div>
  );
}

function StepRow({ s, baseline, active, onClick, isCurrent }) {
  const better = s.score > (s.step === 0 ? -1 : 0) && s.kept;
  return (
    <div className={`step-row ${active ? "active" : ""}`} onClick={onClick}>
      <span className="ix tnum">#{String(s.step).padStart(2, "0")}</span>
      <span className={`status ${isCurrent ? "run" : s.kept ? "win" : "lose"}`}>
        {isCurrent ? <><span className="dot amber pulse" /> running</> : s.kept ? <><I.check style={{ width: 11, height: 11 }} /> kept</> : "rejected"}
      </span>
      <span className="preview">{s.preview}</span>
      <span className="score tnum">{s.score.toFixed(3)}</span>
      <span className={`delta ${s.delta > 0 ? "up" : s.delta < 0 ? "down" : ""}`}>
        {s.delta > 0 ? "+" : ""}{s.delta.toFixed(3)}
      </span>
      <span className="arrow faint"><I.arrow /></span>
    </div>
  );
}

function TabOverview({ run, trajectory, currentStep }) {
  const best = run.best ?? Math.max(...trajectory.map((s) => s.score), run.baseline ?? 0);
  const baseline = run.baseline ?? trajectory[0]?.score ?? 0;
  const improvement = baseline ? ((best - baseline) / baseline * 100) : 0;
  const rewriterCalls = trajectory.length;
  const targetCalls = trajectory.length * run.samples + run.samples;

  return (
    <div className="col" style={{ gap: 16 }}>
      <div className="grid-4">
        <div className="card" style={{ padding: "14px 16px" }}>
          <div className="stat">
            <div className="lbl">Best score</div>
            <div className="val tnum">{best.toFixed(3)}
              <span className={`delta ${improvement > 0 ? "up" : "down"}`}>
                {improvement > 0 ? "+" : ""}{improvement.toFixed(1)}%
              </span>
            </div>
            <div className="sub">{run.metric}</div>
          </div>
        </div>
        <div className="card" style={{ padding: "14px 16px" }}>
          <div className="stat">
            <div className="lbl">Baseline</div>
            <div className="val tnum">{baseline.toFixed(3)}</div>
            <div className="sub">initial system instruction</div>
          </div>
        </div>
        <div className="card" style={{ padding: "14px 16px" }}>
          <div className="stat">
            <div className="lbl">Best step</div>
            <div className="val tnum">#{trajectory.findIndex((s) => s.score === best) >= 0 ? String(trajectory.findIndex((s) => s.score === best)).padStart(2, "0") : "—"}</div>
            <div className="sub">{trajectory.filter((s) => s.kept).length} of {trajectory.length} accepted</div>
          </div>
        </div>
        <div className="card" style={{ padding: "14px 16px" }}>
          <div className="stat">
            <div className="lbl">Inference calls</div>
            <div className="val tnum">{targetCalls.toLocaleString()}</div>
            <div className="sub">{rewriterCalls} rewriter · 0 judge</div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <div className="t">Score trajectory</div>
          <div className="m">{run.metric}, higher is better</div>
          <div className="actions">
            <span className="badge outline" style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
              <span className="dot" style={{ background: "var(--accent)" }} /> running best
            </span>
            <span className="badge outline" style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
              <span className="dot gray" /> candidate
            </span>
            <span className="badge outline">baseline</span>
          </div>
        </div>
        <div style={{ padding: "12px 8px 4px" }}>
          <TrajectoryChart steps={trajectory} currentStep={currentStep} baseline={baseline} metric={run.metric} />
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-head">
            <div className="t">Provider chain</div>
            <div className="actions"><button className="btn btn-icon"><I.cog /></button></div>
          </div>
          <div className="card-body">
            <KV items={[
              ["target", run.target],
              ["rewriter", run.rewriter],
              ["judge", run.judge],
              ["dataset", `${run.dataset} · n=${run.samples}`],
              ["mode", <ModeChip m={run.mode} />],
              ["metric", <span style={{ fontFamily: "var(--font-mono)" }}>{run.metric}</span>],
            ]} />
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="t">Resource budget</div>
            <div className="m">target qps 5.0 · eval qps 5.0</div>
          </div>
          <div className="card-body col" style={{ gap: 12 }}>
            <BudgetRow label="Target inference" used={targetCalls} cap={run.samples * run.totalSteps + run.samples} />
            <BudgetRow label="Rewriter calls" used={rewriterCalls} cap={run.totalSteps} />
            <BudgetRow label="Wall clock" used={6.5} cap={11} unit=" min" />
          </div>
        </div>
      </div>
    </div>
  );
}

function ModeChip({ m }) {
  const map = {
    instruction: { tone: "blue", label: "instruction" },
    demonstration: { tone: "violet", label: "demonstration" },
    instruction_and_demo: { tone: "teal", label: "instruction + demo" },
  };
  const { tone, label } = map[m] || { tone: "gray", label: m };
  return <span className={`badge ${tone}`}>{label}</span>;
}

function BudgetRow({ label, used, cap, unit = "" }) {
  const pct = Math.min(100, (used / cap) * 100);
  return (
    <div>
      <div className="row" style={{ marginBottom: 4 }}>
        <span style={{ fontSize: 12, color: "var(--ink-2)" }}>{label}</span>
        <span className="spacer" />
        <span className="tnum faint" style={{ fontSize: 11 }}>{used}{unit} / {cap}{unit}</span>
      </div>
      <div className="bar-meter"><div className="fill" style={{ width: `${pct}%` }} /></div>
    </div>
  );
}

function TabTrajectory({ trajectory, baseline, currentStep, onSelectStep, selectedStep }) {
  return (
    <div className="grid-2" style={{ gridTemplateColumns: "1.4fr 1fr", alignItems: "start" }}>
      <div className="card">
        <div className="card-head">
          <div className="t">Steps</div>
          <div className="m">{trajectory.length} candidates · {trajectory.filter((s) => s.kept).length} accepted</div>
          <div className="actions">
            <button className="btn btn-icon"><I.download /></button>
          </div>
        </div>
        <div className="steps">
          <div className="step-row" style={{ borderBottom: "1px solid var(--line)", color: "var(--ink-4)", fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", cursor: "default" }}>
            <span>step</span><span>status</span><span>candidate (preview)</span><span style={{ textAlign: "right" }}>score</span><span style={{ textAlign: "right" }}>Δ</span><span></span>
          </div>
          {trajectory.map((s) => (
            <StepRow
              key={s.step}
              s={s}
              baseline={baseline}
              active={selectedStep === s.step}
              isCurrent={currentStep === s.step}
              onClick={() => onSelectStep(s.step)}
            />
          ))}
          {currentStep != null && currentStep === trajectory.length && (
            <div className="step-row" style={{ opacity: 0.7 }}>
              <span className="ix tnum">#{String(currentStep).padStart(2, "0")}</span>
              <span className="status run"><span className="dot amber pulse" /> running</span>
              <span className="preview faint">awaiting rewriter…</span>
              <span className="score faint">—</span>
              <span className="delta faint">—</span>
              <span></span>
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <div className="t">Step #{String(selectedStep).padStart(2, "0")}</div>
          <div className="m">
            {trajectory[selectedStep]?.kept ? (
              <Badge tone="green">accepted</Badge>
            ) : (
              <Badge tone="gray">rejected</Badge>
            )}
          </div>
          <div className="actions">
            <button className="btn"><I.copy /> copy</button>
          </div>
        </div>
        <div className="card-body col" style={{ gap: 12 }}>
          <KV items={[
            ["score", <span className="tnum">{trajectory[selectedStep]?.score.toFixed(3)}</span>],
            ["delta vs prev", <span className={`tnum ${(trajectory[selectedStep]?.delta || 0) > 0 ? "up-text" : "down-text"}`} style={{ color: (trajectory[selectedStep]?.delta || 0) > 0 ? "var(--green)" : "var(--red)" }}>
              {(trajectory[selectedStep]?.delta || 0) > 0 ? "+" : ""}{trajectory[selectedStep]?.delta.toFixed(3)}
            </span>],
            ["rewriter", "claude-sonnet-4"],
            ["evaluated on", `50 samples`],
          ]} />
          <div>
            <div className="faint" style={{ fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 6 }}>
              Candidate instruction (preview)
            </div>
            <pre className="code" style={{ maxHeight: 240, overflow: "auto" }}>
{trajectory[selectedStep]?.preview}{"\n\n…"}
            </pre>
          </div>
          <div>
            <div className="faint" style={{ fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 6 }}>
              Rewriter rationale
            </div>
            <div className="muted" style={{ fontSize: 12, lineHeight: 1.55 }}>
              The previous candidate left output formatting under-specified, allowing the model
              to emit prose alongside the test module. This step constrains output to a single
              <code style={{ background: "var(--bg-3)", padding: "0 4px", borderRadius: 3 }}>.py</code> file
              and explicitly forbids markdown fences.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TabResults({ run, trajectory }) {
  const [tab, setTab] = useStateRD("instruction");
  const [sampleQ, setSampleQ] = useStateRD("");
  const samples = window.PER_SAMPLE.filter((s) =>
    !sampleQ || s.requirement.toLowerCase().includes(sampleQ.toLowerCase())
  );

  return (
    <div className="col" style={{ gap: 16 }}>
      <div className="card">
        <div className="card-head">
          <div className="t">Best instruction</div>
          <div className="m">step #{trajectory.findIndex((s) => s.score === Math.max(...trajectory.map((x) => x.score)))} · {(run.best ?? 0.847).toFixed(3)} {run.metric}</div>
          <div className="actions">
            <div className="seg">
              <button className={tab === "instruction" ? "on" : ""} onClick={() => setTab("instruction")}>view</button>
              <button className={tab === "diff" ? "on" : ""} onClick={() => setTab("diff")}>diff vs baseline</button>
            </div>
            <button className="btn"><I.copy /> copy</button>
            <button className="btn"><I.download /> .txt</button>
          </div>
        </div>
        <div className="card-body">
          {tab === "instruction" ? (
            <pre className="code" style={{ maxHeight: 360, overflow: "auto" }}>{window.BEST_INSTRUCTION}</pre>
          ) : (
            <pre className="code" style={{ maxHeight: 360, overflow: "auto" }}>
              <span className="del">{`You are an expert test automation engineer.\nGiven an API context and a requirement, write a Python test script\nthat exercises the requirement using pytest.\n`}</span>
              <span className="add">{`You are a senior test-automation engineer producing pytest modules\nfor a Camera Hardware Abstraction Layer.\n\nHard requirements (apply EVERY time):\n1. Output a single, self-contained .py module — no prose, no fences.\n2. The first non-import line MUST be a module-level docstring summarising\n   the requirement under test in one sentence.\n3. Use pytest.mark.parametrize whenever the requirement implies a\n   range of inputs (brightness 0–100, exposure stops, focus distances).\n4. For hardware mocks, derive a fixture from conftest.MockCamera\n   rather than instantiating real classes.\n5. Each test function name must follow test_<feature>_<condition>_<expectation>.\n6. End every file with a single if __name__ == "__main__": pytest.main(...).\n\nIf the requirement is ambiguous, prefer the more conservative test\n(narrower input range, stricter assertions). Never invent API surface\nthat is not visible in the provided context.`}</span>
            </pre>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <div className="t">Per-sample evaluation</div>
          <div className="m">before vs after on the eval split</div>
          <div className="actions">
            <div style={{ position: "relative" }}>
              <I.search style={{ position: "absolute", left: 8, top: 7, width: 12, height: 12, color: "var(--ink-4)" }} />
              <input className="input" placeholder="filter requirements…" value={sampleQ} onChange={(e) => setSampleQ(e.target.value)}
                     style={{ paddingLeft: 26, width: 200 }} />
            </div>
            <button className="btn btn-icon"><I.download /></button>
          </div>
        </div>
        <div>
          <div className="sample" style={{ background: "var(--panel-2)", borderTop: "1px solid var(--line)", color: "var(--ink-4)", fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", cursor: "default" }}>
            <span>#</span><span>requirement</span><span>before</span><span>after</span><span style={{ textAlign: "right" }}>Δ</span><span></span>
          </div>
          {samples.slice(0, 12).map((s) => (
            <div className="sample" key={s.id}>
              <span className="ix tnum">{String(s.id).padStart(2, "0")}</span>
              <span className="clip">{s.requirement}</span>
              <span className="score mid tnum">{s.before.toFixed(2)}</span>
              <span className="score mid tnum" style={{ color: s.after > s.before ? "var(--green)" : "var(--red)" }}>{s.after.toFixed(2)}</span>
              <span className={`score ${s.delta > 0.05 ? "good" : s.delta < -0.02 ? "bad" : "mid"} tnum`}>
                {s.delta > 0 ? "+" : ""}{s.delta.toFixed(2)}
              </span>
              <span className="arrow faint"><I.arrow /></span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TabFailures() {
  return (
    <div className="col" style={{ gap: 12 }}>
      <div className="muted" style={{ fontSize: 12 }}>
        These were the worst-scoring (input, expected, response) triples sent to the rewriter at this step.
        The rewriter was asked to identify the failure mode and propose a fix.
      </div>
      {window.SAMPLE_FAILURES.map((f) => (
        <div className="card" key={f.id}>
          <div className="card-head">
            <div className="t">Sample #{f.id}</div>
            <div className="m">score · {f.score.toFixed(2)}</div>
            <div className="actions">
              <Badge tone="red">failure</Badge>
            </div>
          </div>
          <div className="card-body" style={{ display: "grid", gridTemplateColumns: "120px 1fr", gap: "10px 16px" }}>
            <div className="faint" style={{ fontSize: 11 }}>requirement</div>
            <div style={{ fontSize: 12 }}>{f.input}</div>
            <div className="faint" style={{ fontSize: 11 }}>expected</div>
            <pre className="code" style={{ margin: 0 }}>{f.expected}</pre>
            <div className="faint" style={{ fontSize: 11 }}>got</div>
            <pre className="code" style={{ margin: 0 }}>{f.got}</pre>
            <div className="faint" style={{ fontSize: 11 }}>judge</div>
            <div style={{ fontSize: 12, color: "var(--red)" }}>{f.judge}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function TabConfig({ run }) {
  const yaml = `# ${run.name}
project_name: "${run.id}"

system_instruction: |
  ${window.BASELINE_INSTRUCTION.split("\n").join("\n  ")}

prompt_template: |
  API Context:
  {api_context}

  Requirement:
  {requirement}

  Write the test script.

dataset_path: "./data/${run.dataset}.jsonl"
output_dir: "./results/${run.id}/"

target_model:
  provider: "openai_compatible"
  base_url: "http://gpu-box-01:8000/v1"
  model: "Qwen2.5-Coder-32B"
  temperature: 0.3
  max_tokens: 2048

rewriter_model:
  provider: "anthropic"
  model: "claude-sonnet-4-20250514"
  api_key: "$ANTHROPIC_API_KEY"
  temperature: 0.7

optimization_mode: "${run.mode}"

eval_metrics:
  - type: ${run.metric}
    weight: 1.0

num_steps: ${run.totalSteps}
target_model_qps: 5.0
data_limit: 50
`;
  return (
    <div className="grid-2" style={{ gridTemplateColumns: "1.4fr 1fr", alignItems: "start" }}>
      <div className="card">
        <div className="card-head">
          <div className="t">config.yaml</div>
          <div className="m">frozen at run start</div>
          <div className="actions">
            <button className="btn"><I.copy /> copy</button>
            <button className="btn"><I.download /></button>
          </div>
        </div>
        <div style={{ padding: 12 }}>
          <Code>{yaml}</Code>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <div className="t">CLI</div>
          <div className="m">reproduce locally</div>
        </div>
        <div className="card-body col" style={{ gap: 8 }}>
          <pre className="code">{`$ promptforge run --config ./configs/${run.id}.yaml \\
    --resume-from-best`}</pre>
          <div className="faint" style={{ fontSize: 11 }}>or via the Python API:</div>
          <pre className="code">{`from promptforge import Optimizer

opt = Optimizer.from_yaml("configs/${run.id}.yaml")
result = opt.run()
print(result.best_instruction)`}</pre>
        </div>
      </div>
    </div>
  );
}

function ScreenRunDetail({ runId, goRuns, animSpeed = 1, autoplayEnabled = true, totalStepsTweak = 10 }) {
  const run = window.RUNS.find((r) => r.id === runId) || window.RUNS[0];
  const isLive = run.status === "running";

  // for live run we animate progressively
  const [trajectory, setTrajectory] = useStateRD(() => {
    if (isLive) return window.FULL_TRAJECTORY.slice(0, run.step + 1);
    return buildHistoricalTrajectory(run);
  });
  const [currentStep, setCurrentStep] = useStateRD(isLive ? run.step + 1 : null);
  const [selectedStep, setSelectedStep] = useStateRD(0);
  const [tab, setTab] = useStateRD(isLive ? "live" : "overview");
  const [paused, setPaused] = useStateRD(!autoplayEnabled);

  useEffectRD(() => {
    if (!isLive || paused) return;
    const id = setInterval(() => {
      setTrajectory((t) => {
        const total = Math.min(window.FULL_TRAJECTORY.length, totalStepsTweak);
        if (t.length >= total) return t;
        const next = window.FULL_TRAJECTORY[t.length];
        return [...t, next];
      });
      setCurrentStep((s) => (s == null ? null : s + 1));
    }, Math.max(700, 2200 / animSpeed));
    return () => clearInterval(id);
  }, [isLive, paused, animSpeed, totalStepsTweak]);

  useEffectRD(() => {
    if (selectedStep >= trajectory.length) setSelectedStep(Math.max(0, trajectory.length - 1));
  }, [trajectory, selectedStep]);

  const baseline = run.baseline ?? trajectory[0]?.score ?? 0;
  const best = Math.max(baseline, ...trajectory.map((s) => s.score));
  const stepsAccepted = trajectory.filter((s) => s.kept).length;

  const tabs = isLive
    ? ["live", "overview", "trajectory", "failures", "config"]
    : ["overview", "trajectory", "results", "failures", "config"];

  return (
    <div data-screen-label={`Run · ${run.id}`}>
      <div className="page-head">
        <button className="btn btn-ghost btn-icon" onClick={goRuns} style={{ marginTop: 4 }}><I.back /></button>
        <div>
          <div className="row" style={{ gap: 10, alignItems: "center" }}>
            <h1 className="page-title" style={{ margin: 0 }}>{run.name}</h1>
            <span className="faint tnum" style={{ fontSize: 13 }}>{run.id}</span>
            <StatusPill s={run.status} step={trajectory.length - (isLive ? 0 : 1)} total={run.totalSteps} />
          </div>
          <div className="page-meta" style={{ marginTop: 6 }}>
            <ModeChip m={run.mode} />
            <span className="sep">·</span>
            <span>{run.dataset}</span>
            <span className="sep">·</span>
            <span>n = {run.samples}</span>
            <span className="sep">·</span>
            <span>started {run.started}</span>
            <span className="sep">·</span>
            <span className="muted">metric · {run.metric}</span>
          </div>
        </div>
        <div className="page-actions">
          {isLive ? (
            <>
              <button className="btn" onClick={() => setPaused((p) => !p)}>
                {paused ? <><I.run /> resume</> : <><I.pause /> pause</>}
              </button>
              <button className="btn btn-icon" title="Open log"><I.flow /></button>
              <button className="btn btn-primary"><I.download /> download artifacts</button>
            </>
          ) : (
            <>
              <button className="btn"><I.copy /> duplicate</button>
              <button className="btn btn-primary"><I.download /> artifacts</button>
            </>
          )}
        </div>
      </div>

      <div className="tabs">
        {tabs.map((t) => (
          <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>
            {t}
            {t === "trajectory" && <span className="count tnum">{trajectory.length}</span>}
            {t === "failures" && <span className="count">{window.SAMPLE_FAILURES.length}</span>}
          </button>
        ))}
      </div>

      {tab === "live" && isLive && (
        <LiveTab run={run} trajectory={trajectory} currentStep={currentStep} baseline={baseline} best={best} stepsAccepted={stepsAccepted} totalSteps={totalStepsTweak} />
      )}
      {tab === "overview" && <TabOverview run={run} trajectory={trajectory} currentStep={currentStep} />}
      {tab === "trajectory" && (
        <TabTrajectory
          trajectory={trajectory}
          baseline={baseline}
          currentStep={currentStep}
          selectedStep={selectedStep}
          onSelectStep={setSelectedStep}
        />
      )}
      {tab === "results" && <TabResults run={run} trajectory={trajectory} />}
      {tab === "failures" && <TabFailures />}
      {tab === "config" && <TabConfig run={run} />}
    </div>
  );
}

function buildHistoricalTrajectory(run) {
  if (!run.trend.length) return [];
  return run.trend.map((score, i) => ({
    step: i,
    score,
    delta: i === 0 ? 0 : score - run.trend[i - 1],
    kept: i === 0 || score > Math.max(...run.trend.slice(0, i)),
    preview: window.FULL_TRAJECTORY[i % window.FULL_TRAJECTORY.length].preview,
  }));
}

function LiveTab({ run, trajectory, currentStep, baseline, best, stepsAccepted, totalSteps }) {
  const logRef = useRefRD(null);
  const visibleLog = window.LIVE_LOG.slice(0, 11 + trajectory.length * 1.5);

  useEffectRD(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [visibleLog.length]);

  const pct = (trajectory.length / totalSteps) * 100;

  return (
    <div className="col" style={{ gap: 16 }}>
      {/* progress bar */}
      <div className="card" style={{ padding: 14 }}>
        <div className="row" style={{ marginBottom: 10 }}>
          <div className="row" style={{ gap: 14 }}>
            <ProgressRing pct={pct} size={32} stroke={3} />
            <div>
              <div style={{ fontSize: 12 }}>Step <b className="tnum">{trajectory.length}</b> of {totalSteps}</div>
              <div className="faint tnum" style={{ fontSize: 11 }}>{pct.toFixed(0)}% · est. {((totalSteps - trajectory.length) * 38).toFixed(0)}s remaining</div>
            </div>
          </div>
          <span className="spacer" />
          <div className="row" style={{ gap: 16 }}>
            <div className="stat" style={{ textAlign: "right" }}>
              <div className="lbl">best</div>
              <div className="val tnum" style={{ fontSize: 16, color: "var(--green)" }}>{best.toFixed(3)}</div>
            </div>
            <div className="stat" style={{ textAlign: "right" }}>
              <div className="lbl">baseline</div>
              <div className="val tnum" style={{ fontSize: 16, color: "var(--ink-3)" }}>{baseline.toFixed(3)}</div>
            </div>
            <div className="stat" style={{ textAlign: "right" }}>
              <div className="lbl">lift</div>
              <div className="val tnum" style={{ fontSize: 16, color: "var(--accent)" }}>+{((best - baseline) / baseline * 100).toFixed(1)}%</div>
            </div>
            <div className="stat" style={{ textAlign: "right" }}>
              <div className="lbl">accepted</div>
              <div className="val tnum" style={{ fontSize: 16 }}>{stepsAccepted}/{trajectory.length}</div>
            </div>
          </div>
        </div>
        <div className="bar-meter green"><div className="fill" style={{ width: `${pct}%` }} /></div>
      </div>

      <div className="grid-2" style={{ gridTemplateColumns: "1.4fr 1fr", alignItems: "stretch" }}>
        <div className="card">
          <div className="card-head">
            <div className="t">Score trajectory</div>
            <div className="m">live · auto-updating</div>
            <div className="actions">
              <span className="badge outline" style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
                <span className="dot amber pulse" /> live
              </span>
            </div>
          </div>
          <div style={{ padding: "12px 8px 4px" }}>
            <TrajectoryChart steps={trajectory} currentStep={currentStep} baseline={baseline} metric={run.metric} />
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="t">Stream log</div>
            <div className="m">stdout · INFO+</div>
            <div className="actions">
              <button className="btn btn-icon"><I.download /></button>
            </div>
          </div>
          <div className="log" ref={logRef}>
            {visibleLog.map((l, i) => (
              <div key={i} className="row" style={{ alignItems: "flex-start", gap: 0 }}>
                <span className="ts tnum">{l.ts}</span>
                <span className={`lv-${l.lv}`} style={{ flex: 1 }}>{renderLog(l.msg)}</span>
              </div>
            ))}
            <div className="row" style={{ alignItems: "flex-start", gap: 0, opacity: 0.7 }}>
              <span className="ts tnum">{nowTs()}</span>
              <span className="lv-info">[Step {trajectory.length}/{totalSteps}] Asking rewriter<span className="dots-loop">...</span></span>
            </div>
          </div>
        </div>
      </div>

      {/* recent steps strip */}
      <div className="card">
        <div className="card-head">
          <div className="t">Recent steps</div>
          <div className="m">latest 6 candidates</div>
        </div>
        <div className="steps">
          {trajectory.slice(-6).map((s) => (
            <StepRow key={s.step} s={s} active={false} isCurrent={false} onClick={() => {}} />
          ))}
        </div>
      </div>
    </div>
  );
}

function renderLog(msg) {
  // bold step prefixes like [Step 6/10]
  return msg.split(/(\[Step [^\]]+\])/g).map((part, i) => {
    if (/^\[Step /.test(part)) return <b key={i}>{part}</b>;
    // metric values
    return part.split(/(rouge_l=[\d.]+|qps=[\d.]+)/g).map((p, j) => {
      if (/^rouge_l=|^qps=/.test(p)) return <span key={`${i}-${j}`} style={{ color: "var(--accent)" }}>{p}</span>;
      return <React.Fragment key={`${i}-${j}`}>{p}</React.Fragment>;
    });
  });
}

function nowTs() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`;
}

window.ScreenRunDetail = ScreenRunDetail;
