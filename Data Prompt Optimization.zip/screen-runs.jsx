/* global React, I, Badge, Sparkline */
const { useState: useStateRuns } = React;

function StatusCell({ s }) {
  if (s === "running") return <Badge tone="amber" dot="amber"><span className="dot amber pulse" />running</Badge>;
  if (s === "completed") return <Badge tone="green">completed</Badge>;
  if (s === "failed") return <Badge tone="red">failed</Badge>;
  if (s === "draft") return <Badge tone="gray" >draft</Badge>;
  return <Badge tone="gray">{s}</Badge>;
}

function ModeBadge({ m }) {
  const map = {
    instruction: { tone: "blue", label: "instruction" },
    demonstration: { tone: "violet", label: "demonstration" },
    instruction_and_demo: { tone: "teal", label: "instruction + demo" },
  };
  const { tone, label } = map[m] || { tone: "gray", label: m };
  return <Badge tone={tone}>{label}</Badge>;
}

function fmt(v) {
  if (v == null) return <span className="faint">—</span>;
  return v.toFixed(3);
}

function ScreenRuns({ goRun, goNew }) {
  const [filter, setFilter] = useStateRuns("all");
  const filtered = window.RUNS.filter((r) => filter === "all" || r.status === filter);

  const counts = {
    all: window.RUNS.length,
    running: window.RUNS.filter((r) => r.status === "running").length,
    completed: window.RUNS.filter((r) => r.status === "completed").length,
    draft: window.RUNS.filter((r) => r.status === "draft").length,
  };

  return (
    <div data-screen-label="Runs Registry">
      <div className="page-head">
        <div>
          <h1 className="page-title">Optimization Runs</h1>
          <div className="page-meta">
            <span>{counts.all} runs</span>
            <span className="sep">·</span>
            <span>{counts.running} running</span>
            <span className="sep">·</span>
            <span>{counts.completed} completed</span>
            <span className="sep">·</span>
            <span>{counts.draft} draft</span>
          </div>
        </div>
        <div className="page-actions">
          <div className="seg">
            {["all", "running", "completed", "failed", "draft"].map((f) => (
              <button key={f} className={filter === f ? "on" : ""} onClick={() => setFilter(f)}>{f}</button>
            ))}
          </div>
          <button className="btn btn-icon" title="Filter"><I.filter /></button>
          <button className="btn btn-icon" title="Layout"><I.list /></button>
          <button className="btn btn-primary" onClick={goNew}><I.plus /> New run</button>
        </div>
      </div>

      <table className="tbl">
        <thead>
          <tr>
            <th style={{ width: "26%" }}>Run</th>
            <th>Status</th>
            <th>Mode</th>
            <th>Target model</th>
            <th>Dataset · n</th>
            <th className="num">Baseline</th>
            <th className="num">Best</th>
            <th>Trajectory</th>
            <th className="num">Steps</th>
            <th>Started</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((r) => (
            <tr key={r.id} onClick={() => goRun(r.id)}>
              <td className="name">
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span className={`dot ${r.status === "running" ? "amber pulse" : r.status === "failed" ? "red" : r.status === "draft" ? "gray" : "green"}`} />
                  <span style={{ display: "flex", flexDirection: "column" }}>
                    <span style={{ color: "var(--ink)" }}>{r.name}</span>
                    <span className="faint" style={{ fontSize: 11 }}>{r.id}</span>
                  </span>
                </div>
              </td>
              <td><StatusCell s={r.status} /></td>
              <td><ModeBadge m={r.mode} /></td>
              <td><span className="muted">{r.target}</span></td>
              <td>
                <span style={{ display: "flex", flexDirection: "column" }}>
                  <span>{r.dataset}</span>
                  <span className="faint" style={{ fontSize: 11 }}>n = {r.samples}</span>
                </span>
              </td>
              <td className="num"><span className="muted">{fmt(r.baseline)}</span></td>
              <td className="num">
                {r.best != null ? (
                  <span style={{ color: r.best > (r.baseline ?? 0) ? "var(--green)" : "var(--red)" }}>{r.best.toFixed(3)}</span>
                ) : <span className="faint">—</span>}
                {r.baseline != null && r.best != null && (
                  <div className="faint tnum" style={{ fontSize: 10 }}>
                    {r.best > r.baseline ? "+" : ""}{((r.best - r.baseline) / r.baseline * 100).toFixed(1)}%
                  </div>
                )}
              </td>
              <td>
                {r.trend.length > 1 ? <Sparkline data={r.trend} w={84} h={20} /> : <span className="faint">—</span>}
              </td>
              <td className="num">
                <span className="tnum">{r.step}/{r.totalSteps}</span>
              </td>
              <td><span className="muted">{r.started}</span></td>
              <td><span className="arrow"><I.arrow /></span></td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginTop: 32 }}>
        <div className="muted" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 8 }}>
          Quick stats — last 30 days
        </div>
        <div className="grid-4">
          <div className="card" style={{ padding: "14px 16px" }}>
            <div className="stat">
              <div className="lbl">Runs completed</div>
              <div className="val">42 <span className="delta up">+18%</span></div>
              <div className="sub">7 still running</div>
            </div>
          </div>
          <div className="card" style={{ padding: "14px 16px" }}>
            <div className="stat">
              <div className="lbl">Median lift</div>
              <div className="val">+14.6% <span className="delta up">+2.1pp</span></div>
              <div className="sub">vs. baseline instruction</div>
            </div>
          </div>
          <div className="card" style={{ padding: "14px 16px" }}>
            <div className="stat">
              <div className="lbl">Inference calls</div>
              <div className="val">218k</div>
              <div className="sub">38k judge · 180k target</div>
            </div>
          </div>
          <div className="card" style={{ padding: "14px 16px" }}>
            <div className="stat">
              <div className="lbl">Mean run time</div>
              <div className="val">7m 24s</div>
              <div className="sub">10 steps × 50 samples</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.ScreenRuns = ScreenRuns;
