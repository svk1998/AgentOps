/* global React */
const { useState, useEffect, useMemo, useRef } = React;

/* ─────────────────────────── icons ─────────────────────────── */
const I = {
  list:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><rect x="2" y="3" width="12" height="2.2" rx="0.6"/><rect x="2" y="7" width="12" height="2.2" rx="0.6"/><rect x="2" y="11" width="12" height="2.2" rx="0.6"/></svg>,
  data:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><ellipse cx="8" cy="4" rx="5.5" ry="1.6"/><path d="M2.5 4v4c0 .9 2.5 1.6 5.5 1.6S13.5 8.9 13.5 8V4"/><path d="M2.5 8v4c0 .9 2.5 1.6 5.5 1.6S13.5 12.9 13.5 12V8"/></svg>,
  prov:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><rect x="2" y="3" width="5" height="4" rx="0.6"/><rect x="9" y="3" width="5" height="4" rx="0.6"/><rect x="2" y="9" width="5" height="4" rx="0.6"/><rect x="9" y="9" width="5" height="4" rx="0.6"/><circle cx="4.5" cy="5" r="0.6" fill="currentColor"/><circle cx="11.5" cy="5" r="0.6" fill="currentColor"/></svg>,
  metric:  (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M2 13l3-4 3 2 5-7"/><path d="M2 13h12"/></svg>,
  run:     (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M5 3.5v9l7-4.5z" fill="currentColor"/></svg>,
  cog:     (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><circle cx="8" cy="8" r="2.2"/><path d="M8 1.5v2M8 12.5v2M14.5 8h-2M3.5 8h-2M12.6 3.4l-1.4 1.4M4.8 11.2l-1.4 1.4M12.6 12.6l-1.4-1.4M4.8 4.8L3.4 3.4"/></svg>,
  search:  (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><circle cx="7" cy="7" r="4.2"/><path d="M10.2 10.2L13.5 13.5"/></svg>,
  plus:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}><path d="M8 3v10M3 8h10"/></svg>,
  arrow:   (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M6 3l5 5-5 5"/></svg>,
  back:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M10 3L5 8l5 5"/></svg>,
  close:   (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M3.5 3.5l9 9M12.5 3.5l-9 9"/></svg>,
  check:   (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}><path d="M3.5 8.5L7 12l5.5-7"/></svg>,
  copy:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><rect x="5" y="5" width="8" height="8" rx="1.2"/><path d="M3 11V4a1 1 0 0 1 1-1h7"/></svg>,
  more:    (p) => <svg viewBox="0 0 16 16" fill="currentColor" {...p}><circle cx="3.5" cy="8" r="1"/><circle cx="8" cy="8" r="1"/><circle cx="12.5" cy="8" r="1"/></svg>,
  pause:   (p) => <svg viewBox="0 0 16 16" fill="currentColor" {...p}><rect x="4" y="3.5" width="2.5" height="9" rx="0.6"/><rect x="9.5" y="3.5" width="2.5" height="9" rx="0.6"/></svg>,
  download:(p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M8 2v8.5M4.5 7L8 10.5 11.5 7M3 13.5h10"/></svg>,
  link:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M6.5 9.5L9.5 6.5"/><path d="M7 4l1.5-1.5a2.5 2.5 0 0 1 3.5 3.5L10.5 7.5"/><path d="M9 12l-1.5 1.5a2.5 2.5 0 0 1-3.5-3.5L5.5 8.5"/></svg>,
  filter:  (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M2.5 3.5h11l-4 5.5v4l-3-1.5V9z"/></svg>,
  spark:   (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M2 12l3-4 3 2 3-5 3 4"/></svg>,
  flow:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><circle cx="3.5" cy="4" r="1.5"/><circle cx="12.5" cy="4" r="1.5"/><circle cx="8" cy="12" r="1.5"/><path d="M5 4h6M4.3 5.3L7.3 10.7M11.7 5.3L8.7 10.7"/></svg>,
  warn:    (p) => <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M8 2.5l6 11H2z"/><path d="M8 6.5v3.5M8 11.8v0.4" strokeWidth="1.6"/></svg>,
};

/* ─────────────────────────── badge ─────────────────────────── */
function Badge({ tone = "gray", children, dot }) {
  return (
    <span className={`badge ${tone}`}>
      {dot && <span className={`dot ${dot}`} />}
      {children}
    </span>
  );
}

/* ─────────────────────────── sparkline ─────────────────────────── */
function Sparkline({ data, w = 80, h = 22, tone }) {
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const xs = data.map((_, i) => (i / (data.length - 1)) * (w - 2) + 1);
  const ys = data.map((d) => h - 2 - ((d - min) / range) * (h - 4));
  const path = xs.map((x, i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${ys[i].toFixed(1)}`).join(" ");
  const trend = tone || (data[data.length - 1] > data[0] + 0.5 ? "up" : data[data.length - 1] < data[0] - 0.5 ? "down" : "flat");
  return (
    <svg className={`spark ${trend}`} width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <path d={path} />
    </svg>
  );
}

/* ─────────────────────────── progress ring ─────────────────────────── */
function ProgressRing({ pct = 0, size = 22, stroke = 2 }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <svg className="ring" width={size} height={size}>
      <circle className="track" cx={size / 2} cy={size / 2} r={r} strokeWidth={stroke} />
      <circle className="bar" cx={size / 2} cy={size / 2} r={r} strokeWidth={stroke}
              strokeDasharray={c} strokeDashoffset={c * (1 - pct / 100)} strokeLinecap="round" />
    </svg>
  );
}

/* ─────────────────────────── code block (very light syntax) ─────────────────────────── */
function highlightYaml(src) {
  // very lightweight tokenizer for yaml-ish strings
  const lines = src.split("\n");
  return lines.map((ln, i) => {
    let out = ln;
    // comments
    if (/^\s*#/.test(ln)) {
      return <span key={i} className="com">{ln + "\n"}</span>;
    }
    // key: value
    const m = ln.match(/^(\s*)([\w_.-]+)(:\s*)(.*)$/);
    if (m) {
      const [, indent, key, sep, rest] = m;
      let val = rest;
      let valEl = val;
      if (/^"[^"]*"$|^'[^']*'$/.test(val.trim())) valEl = <span className="str">{val}</span>;
      else if (/^-?\d+(\.\d+)?$/.test(val.trim())) valEl = <span className="num">{val}</span>;
      else if (/^(true|false|null)$/.test(val.trim())) valEl = <span className="kw">{val}</span>;
      return <span key={i}>{indent}<span className="kw">{key}</span>{sep}{valEl}{"\n"}</span>;
    }
    return <span key={i}>{ln + "\n"}</span>;
  });
}

function Code({ children, lang = "yaml" }) {
  return <pre className="code">{lang === "yaml" ? highlightYaml(children) : children}</pre>;
}

/* ─────────────────────────── kv ─────────────────────────── */
function KV({ items }) {
  return (
    <div className="kv">
      {items.map(([k, v]) => (
        <React.Fragment key={k}>
          <div className="k">{k}</div>
          <div className="v">{v}</div>
        </React.Fragment>
      ))}
    </div>
  );
}

/* ─────────────────────────── trajectory chart ─────────────────────────── */
function TrajectoryChart({ steps, currentStep, baseline, metric = "rouge_l" }) {
  const W = 720, H = 280, P = { l: 44, r: 16, t: 16, b: 28 };
  const innerW = W - P.l - P.r;
  const innerH = H - P.t - P.b;
  const yMin = 0.4, yMax = 1.0;
  const xMax = Math.max(steps.length - 1, 9);

  const x = (i) => P.l + (i / xMax) * innerW;
  const y = (v) => P.t + (1 - (v - yMin) / (yMax - yMin)) * innerH;

  // best line — running max over candidates
  let runningBest = baseline;
  const bestPts = steps.map((s, i) => {
    if (s.score > runningBest) runningBest = s.score;
    return { i, v: runningBest, score: s.score, ok: s.score > (i > 0 ? steps[i - 1].score : baseline) };
  });

  // the candidate (raw) line
  const candPath = steps.map((s, i) => `${i === 0 ? "M" : "L"}${x(i)} ${y(s.score)}`).join(" ");
  const bestPath = bestPts.map((p, i) => `${i === 0 ? "M" : "L"}${x(i)} ${y(p.v)}`).join(" ");
  const areaPath = bestPath + ` L${x(bestPts.length - 1)} ${P.t + innerH} L${x(0)} ${P.t + innerH} Z`;

  return (
    <svg className="trajectory-svg" viewBox={`0 0 ${W} ${H}`}>
      {/* gridlines */}
      <g className="grid">
        {[0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0].map((v) => (
          <line key={v} x1={P.l} x2={W - P.r} y1={y(v)} y2={y(v)} />
        ))}
      </g>
      <g className="axis">
        {[0.4, 0.6, 0.8, 1.0].map((v) => (
          <text key={v} x={P.l - 8} y={y(v) + 3} textAnchor="end">{v.toFixed(1)}</text>
        ))}
        {Array.from({ length: xMax + 1 }, (_, i) => i).filter((i) => i % 2 === 0).map((i) => (
          <text key={i} x={x(i)} y={H - 10} textAnchor="middle">{i}</text>
        ))}
      </g>
      {/* baseline */}
      <line className="baseline" x1={P.l} x2={W - P.r} y1={y(baseline)} y2={y(baseline)} />
      <text x={W - P.r - 4} y={y(baseline) - 4} textAnchor="end" style={{ fontSize: 10, fill: "var(--ink-4)", fontFamily: "var(--font-mono)" }}>
        baseline · {baseline.toFixed(3)}
      </text>
      {/* area + best line */}
      <path className="area" d={areaPath} />
      <path className="candidate-line" d={candPath} />
      <path className="best-line" d={bestPath} />
      {/* points */}
      {steps.map((s, i) => {
        const better = s.score > (i > 0 ? Math.max(...steps.slice(0, i).map((x) => x.score), baseline) : baseline);
        return (
          <circle key={i} cx={x(i)} cy={y(s.score)} r={better ? 3.4 : 2.6}
                  className={better ? "pt-best" : "pt-rej"} />
        );
      })}
      {/* current step marker */}
      {currentStep !== undefined && currentStep < steps.length && (
        <line className="marker-current" x1={x(currentStep)} x2={x(currentStep)} y1={P.t} y2={P.t + innerH} />
      )}
      <text x={W - P.r} y={P.t + 12} textAnchor="end" style={{ fontSize: 10, fill: "var(--ink-3)", fontFamily: "var(--font-mono)" }}>
        {metric.toUpperCase()}
      </text>
    </svg>
  );
}

Object.assign(window, { I, Badge, Sparkline, ProgressRing, Code, KV, TrajectoryChart, highlightYaml });
